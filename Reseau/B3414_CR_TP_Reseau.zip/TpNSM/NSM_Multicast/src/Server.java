/**
 * Classe rep�sentant le serveur du tchat.
 * 
 * @author Lo�c CASTELLON & Florian MUTIN 3IF4
 * 
 */
public class Server
{
	final public static String DECONNEXION = "deco";
	final public static String IP = "239.255.80.84";
	final public static int PORT = 5001;
}
